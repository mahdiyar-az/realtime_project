import random
from task import Task
from uunifast import uunifast

class core:
    def __init__(self):

        self.tasks = []




