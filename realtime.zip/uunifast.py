import random

from task import Task


def uunifast(num_tasks, total_utilization):
    utilizations = []
    sum_u = total_utilization
    for i in range(1, num_tasks):
        next_sum_u = sum_u * (random.random() ** (1 / (num_tasks - i)))
        utilizations.append(sum_u - next_sum_u)
        sum_u = next_sum_u
    utilizations.append(sum_u)
    return utilizations

def generate_tasks(num_tasks,num_cores, core_efficiency):
    total_utilization = num_cores*core_efficiency
    utilizations = uunifast(num_tasks, total_utilization)
    tasks = []
    for i, util in enumerate(utilizations):
        period = random.randint(50, 200)
        wcet = round(util * period, 2)
        deadline = period
        task_type = 'hard' if i < num_tasks // 2 else 'soft'

        task = Task(i + 1, util, wcet, period, deadline, task_type)
        tasks.append(task)

    return tasks
