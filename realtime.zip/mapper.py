def wfd_mapping(tasks, cores):
    # فقط وظایف سخت
    print(len(tasks),len(cores))
    hard_tasks = [t for t in tasks if t.task_type == 'hard']

    # مرتب‌سازی نزولی بر اساس بهره‌وری
    hard_tasks.sort(key=lambda t: t.utilization, reverse=True)

    for task in hard_tasks:
        # پیدا کردن هسته با کمترین مجموع بهره‌وری فعلی
        target_core = min(cores, key=lambda c: sum(t.utilization for t in c.tasks))
        target_core.tasks.append(task)

    return cores


def edf_schedule(core):
    # مرتب‌سازی وظایف هر هسته بر اساس deadline صعودی
    return sorted(core.tasks, key=lambda t: t.deadline)
